export class Feedback {
  public technologyId: number;
  public technologyName: string;
  public featureWiseFeedback: number[];
  public technologyAverageFeedback: number;
}
