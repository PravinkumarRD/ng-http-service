import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technology-feedback',
  templateUrl: './technology-feedback.component.html',
  styleUrls: ['./technology-feedback.component.css']
})
export class TechnologyFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
