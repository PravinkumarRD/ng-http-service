import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnologyFeedbackComponent } from './technology-feedback.component';

describe('TechnologyFeedbackComponent', () => {
  let component: TechnologyFeedbackComponent;
  let fixture: ComponentFixture<TechnologyFeedbackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnologyFeedbackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TechnologyFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
