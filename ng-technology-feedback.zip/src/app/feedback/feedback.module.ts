import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TechnologyFeedbackComponent } from './components/technology-feedback/technology-feedback.component';



@NgModule({
  declarations: [
    TechnologyFeedbackComponent
  ],
  imports: [
    CommonModule
  ]
})
export class FeedbackModule { }
