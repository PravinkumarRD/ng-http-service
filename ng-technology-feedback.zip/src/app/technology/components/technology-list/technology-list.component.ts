import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";

import { Technology } from "../../models/technology";

import { TechnologyService } from "../../services/technology.service";

@Component({
  selector: 'technology-list',
  templateUrl: './technology-list.component.html',
  styleUrls: ['./technology-list.component.css']
})
export class TechnologyListComponent implements OnInit, OnDestroy {

  constructor(private _technologyService: TechnologyService) {

  }

  public title: string = "Welcome To Technology List!";
  public subTitle: string = "Choose the correct technology to give a feedback!";
  public technologies: Technology[];
  public searchChars: string = "";
  public currentPage: number = 0;
  public selectedTechnologyId: number;

  private _subscription: Subscription;

  ngOnInit(): void {
    this._subscription = this._technologyService.getAllTechnologies().subscribe(
      data => this.technologies = data,
      error => console.log(error)
    );
  }

  public onTechnologySelection(technologyId: number): void {
    this.selectedTechnologyId = technologyId;
  }

  ngOnDestroy(): void {
    if (this._subscription) this._subscription.unsubscribe();
  }
}
