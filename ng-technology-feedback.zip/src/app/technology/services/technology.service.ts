import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { Technology } from "../models/technology";

@Injectable()
export class TechnologyService {
  constructor(private _httpClient: HttpClient) { }

  getAllTechnologies(): Observable<Technology[]> {
    return this._httpClient.get<Technology[]>("http://localhost:9090/api/technologies");
  }
  getTechnologyDetails(technologyId: number): Observable<Technology> {
    return this._httpClient.get<Technology>(`http://localhost:9090/api/technologies/${technologyId}`);
  }
}
